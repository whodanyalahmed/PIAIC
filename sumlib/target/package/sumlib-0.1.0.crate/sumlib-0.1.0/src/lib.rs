pub mod grand{

    pub mod section1{
            
        pub fn add(a: i32 ,b: i32) -> i32{
            a+b

        }
    }
    pub mod section2{
        
        pub fn sub(a: i32 ,b: i32) -> i32{
            a-b
            
        }
    }


}


