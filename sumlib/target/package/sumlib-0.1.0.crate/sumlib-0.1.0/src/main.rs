mod lib;
use lib::grand::section1::*;
fn main(){
    print!("Hello! world" );
    let result = add(2,4);
    print!("{}",result );
}

// 03032536484
// wajaht ali